<!doctype html>
<html lang="en">
<title>RCI</title>
<meta charset="utf-8" />

<body style="background: #fff;">
    <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff"
        style="border-radius: 0px; margin: 0 auto;">
        <tbody>
            <tr>
                <td style="padding:0 0px">
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
                        <tbody>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 600; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; text-decoration: underline;">
                                    CENTER FOR HIGHENERGY SYSTEMS & SCIENCES (CHESS) <br>
                                    RCI CAMPUS, HYDERABAD - 500 069 <br>
                                    CERTIFICATE RECEIPT VOUCHER (CRV) <br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding:0 0px">
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
                        <tbody>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    SIR NO: &nbsp; 0123
                                </td>
                                <td colspan="2"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    DC/INVOICE NO: &nbsp; ABC -0123
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    RIN NO: &nbsp; 0123
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    CRV NO: &nbsp; 01234
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    SIR DATE: &nbsp; 01|01|000
                                </td>
                                <td colspan="2"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    DC/INVOICE NO DATE: &nbsp; 01|01|000
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    RIN NO DATE: &nbsp; 01|01|000
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; text-transform: uppercase; border: 1px solid #000;">
                                    CRV DATE: &nbsp; 01|02|003
                                </td>
                            </tr>
                            <tr>
                                <td colspan="5"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Consignor's Name & address: M/S. &nbsp; -ABCD
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="padding:0 0px">
                    <table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
                        <tbody>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Authority: &nbsp; -ABCD :01234<br>
                                    Date: &nbsp; 01|02|003
                                </td>
                                <td colspan="6"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Cost Debatable to Budget Head: &nbsp; -ABCD <br>
                                </td>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Project No.: &nbsp; 02C4<br>
                                    Project Code: &nbsp; 12345 ABC
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    SI.No.

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Item Code
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Nomenclature/ description of Stores
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    C/ NC

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    A/U
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Qty
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Rate<br> (Rs.)
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Tax %
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Total Cost <br> (Rs.)
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Ledger <br>No.
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Folio <br>No.
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Remarks
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    01

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    01-01-000
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    ABCD
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    NC

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    No
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000;">
                                    01
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000;">
                                    500
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000;">
                                    5%
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000;">
                                    750
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    01
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    14
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000;">
                                    ABCD
                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    02

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    01-08-000
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    ABCD
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    C

                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    LTR
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    02
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    50
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    18%
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    350
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    08
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">
                                    15
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; ">

                                </td>
                            </tr>
                            <tr>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important;  border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Total Number Number of Items:
                                </td>
                                <td colspan="5"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Total Item Cost (Rs.) <span style="text-align: right;">550</span>
                                </td>
                                <td colspan="4"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    1100/-
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;  border-right: 1px solid #000; height: 100px;">
                                    <br><br><br><br><br><br>
                                    O I/c.<br><br>
                                    Stores Officer <br><br>
                                    Date:
                                </td>
                                <td colspan="5"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    Inclusive of taxes TOTAL COST (Rs.)<br>
                                    In words: Eleven hundred only
                                </td>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">
                                    1100/-
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border: 1px solid #000;">

                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;">

                                </td>
                                <td colspan="9"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: center; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;  border-right: 1px solid #000;  ">
                                    The above stores have been taken on charge and posted in Ledger
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;">
                                    I/ c. Ledger
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000;">
                                    I/c. Ledger Accounting
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                  
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000; height: 10px;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                  
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000; height: 10px;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000;">
                                    SSO-II
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000;">
                                    Stores Officer
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                  
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000; height: 10px;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; height: 10px;">
                                  
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000; height: 10px;">
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-bottom: 1px solid #000; border-left: 1px solid #000;">
                                </td>
                                <td colspan="8"
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-left: 1px solid #000; border-bottom: 1px solid #000;">
                                    Date:
                                </td>
                                <td
                                    style="font-size: 10px; line-height: 14px; font-weight: 400; color: #000; text-align: left; padding: 0px 5px !important; margin: 0px 0px !important; border-right: 1px solid #000; border-bottom: 1px solid #000;">
                                    Date:
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>