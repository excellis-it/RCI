<?php

namespace App\Constants;

class Quaterly
{

    const QUATERLY = [
        'mar-apr-may' => 'Q1',
        'jun-jul-aug' => 'Q2',
        'sep-oct-nov' => 'Q3',
        'dec-jan-feb' => 'Q4',
    ];

    
}
