<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TadaJourneyDetail extends Model
{
    use HasFactory;
    protected $table = 'tada_journey_details';
}
