<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TadaPriority extends Model
{
    use HasFactory;
    protected $table = 'tada_priority';
}
