<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MemberMonthlyData extends Model
{
    use HasFactory;

    protected $table = 'members_monthly_data';
}
